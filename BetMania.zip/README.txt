Working navigation between user and admin panel.
LoginRegister Link doesnt work.
