﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BetMania.Services.Helpers
{
    public enum MatchStatusQuery
    {
        All = 0,
        Upcoming = 1,
        InProgress = 2,
        Finished = 3
    }
}