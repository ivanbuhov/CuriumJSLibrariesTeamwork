﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BetMania.Services.Models
{
    public class BetAdditionDTO
    {
        public decimal Amount { get; set; }
        public string BetType { get; set; }
    }
}